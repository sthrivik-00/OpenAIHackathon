#include <ming.h>
#include <ch.h>
#include <stdio.h>

EXPORTCH void Ming_setErrorFunction_chdl(void *varg) {
   printf("ChMing V2.0.0: Ming_setErrorFunction() is not available in this version\n");
}
